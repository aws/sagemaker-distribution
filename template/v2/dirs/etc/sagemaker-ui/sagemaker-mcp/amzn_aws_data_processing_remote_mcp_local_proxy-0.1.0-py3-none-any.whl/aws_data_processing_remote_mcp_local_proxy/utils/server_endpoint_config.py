from typing import Any, Dict

"""
We will not need this dictionary after we have dataprocessing-mcp.<region>.api.aws
"""
REMOTE_MCP_SERVER_ENDPOINT_DICT: Dict[str, Any] = {
    "beta": {
        "us-west-2": "https://i5n8wpbiv8.execute-api.us-west-2.amazonaws.com/beta/",
        "us-east-2": "https://6bfou3r5hh.execute-api.us-east-2.amazonaws.com/beta/",
        "us-east-1": "https://z2co5mmtg9.execute-api.us-east-1.amazonaws.com/beta/",
    }
}
