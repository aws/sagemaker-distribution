"""
Utilities for AWS Data Processing Remote MCP Local Proxy.

This package contains utility modules for the AWS Data Processing Remote MCP Local Proxy,
including SigV4 signing and authentication utilities.
"""
