import logging
import os

import boto3
from httpx import Auth

from aws_data_processing_remote_mcp_local_proxy.utils.sigv4_signer import SigV4Signer

# Configure logging
logging.basicConfig(
    level=logging.DEBUG, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("SigV4CustomAuth")


class SigV4CustomAuth(Auth):
    """Custom SigV4 authentication implementation for HTTPX."""

    requires_request_body = True

    def __init__(self, service, region, algorithm="AWS4-HMAC-SHA256"):
        logger.debug(f"Initializing SigV4CustomAuth for service={service}, region={region}")
        self.service = service
        self.region = region
        self.algorithm = algorithm

    def auth_flow(self, request):
        logger.debug("SigV4CustomAuth.auth_flow called for request")
        # Option 1: Fetch AWS credentials from environment variables
        aws_access_key = os.getenv("AWS_ACCESS_KEY_ID")
        aws_secret_key = os.getenv("AWS_SECRET_ACCESS_KEY")
        aws_session_token = os.getenv("AWS_SESSION_TOKEN")

        # Option 2: Fetch AWS credentials from supplied AWS profile name
        aws_profile_name = os.getenv("AWS_PROFILE_NAME")

        # Get credentials from boto3 or environment variables
        if aws_access_key and aws_secret_key and aws_session_token:
            logger.debug("Using credentials from environment variables")
            access_key = aws_access_key
            secret_key = aws_secret_key
            token = aws_session_token
        elif aws_profile_name:
            logger.debug("Fetching credentials from aws profile {aws_profile_name}")
            credentials = boto3.Session(profile_name=aws_profile_name).get_credentials()
            access_key = credentials.access_key
            secret_key = credentials.secret_key
            token = credentials.token
            logger.debug(f"Successfully fetched credentials from aws profile {aws_profile_name}")
        else:
            logger.debug("Fetching credentials from default aws profile")
            credentials = boto3.Session().get_credentials()
            access_key = credentials.access_key
            secret_key = credentials.secret_key
            token = credentials.token
            logger.debug("Successfully fetched credentials from default aws profile")

        sigv4_signer = SigV4Signer(
            access_key=access_key,
            secret_key=secret_key,
            service=self.service,
            region=self.region,
            token=token,
        )

        request = sigv4_signer.__call__(request)

        logger.debug(f"Final request headers: {request.headers}")
        logger.debug(f"authorization: {request.headers.get('authorization')}")
        yield request
