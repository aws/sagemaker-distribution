import hashlib
import hmac
import logging
from datetime import datetime
from typing import Optional

from httpx import Request

# Configure logging
logging.basicConfig(
    level=logging.DEBUG, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("SigV4Signer")


class SigV4Signer:
    def __init__(
        self,
        access_key: str,
        secret_key: str,
        service: str,
        region: str,
        token: Optional[str] = None,
    ):
        self._access_key = access_key
        self._secret_key = secret_key
        self._token = token
        self._service = service
        self._region = region
        self._signed_headers = "host;x-amz-date"

        # the hashing algorithm that you use to calculate the digests in the canonical request
        self._algorithm = "AWS4-HMAC-SHA256"

    # ref: https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_sigv-create-signed-request.html#derive-signing-key
    def get_signature_key(self, date_stamp: str) -> bytes:

        def hmacsha256(key, msg):
            return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()

        date_key = hmacsha256(("AWS4" + self._secret_key).encode("utf-8"), date_stamp)
        date_region_key = hmacsha256(date_key, self._region)
        date_region_key_service_key = hmacsha256(date_region_key, self._service)
        signing_key = hmacsha256(date_region_key_service_key, "aws4_request")
        return signing_key

    def get_canonical_request(self, request: Request, timestamp: str) -> str:
        canonical_uri = request.url.path
        canonical_querystring = request.url.query.decode("utf-8")
        logger.debug(f"Canonical URI: {canonical_uri}")
        logger.debug(f"Canonical Query String: {canonical_querystring}")
        canonical_headers = f"host:{request.url.host}\nx-amz-date:{timestamp}\n"

        if request.content:
            payload_hash = hashlib.sha256(request.content).hexdigest()
        else:
            payload_hash = hashlib.sha256(("").encode("utf-8")).hexdigest()

        logger.debug(f"Payload hash: {payload_hash}")

        canonical_request = (
            f"{request.method}\n{canonical_uri}\n{canonical_querystring}\n"
            f"{canonical_headers}\n{self._signed_headers}\n{payload_hash}"
        )
        return canonical_request

    def get_authorization_header(self, credential_scope: str, signature: str) -> str:
        return (
            f"{self._algorithm} Credential={self._access_key}/{credential_scope},"
            f" SignedHeaders={self._signed_headers}, Signature={signature}"
        )

    def __call__(self, request: Request) -> Request:
        # Create a date for headers and the credential string
        current_time = datetime.utcnow()
        timestamp = current_time.strftime("%Y%m%dT%H%M%SZ")
        datestamp = current_time.strftime("%Y%m%d")  # Date w/o time, used in credential scope

        if request.content:
            payload_hash = hashlib.sha256(request.content).hexdigest()
        else:
            payload_hash = hashlib.sha256(("").encode("utf-8")).hexdigest()

        # CREATE A CANONICAL REQUEST
        canonical_request = self.get_canonical_request(request=request, timestamp=timestamp)
        canonical_request_hash = hashlib.sha256(canonical_request.encode("utf-8")).hexdigest()

        # CREATE THE STRING TO SIGN
        credential_scope = f"{datestamp}/{self._region}/{self._service}/aws4_request"
        string_to_sign = (
            f"{self._algorithm}\n{timestamp}\n{credential_scope}\n{canonical_request_hash}"
        )

        # CALCULATE THE SIGNATURE
        signing_key = self.get_signature_key(datestamp)
        signature = hmac.new(
            signing_key, (string_to_sign).encode("utf-8"), hashlib.sha256
        ).hexdigest()

        # GENERATE AUTHORIZATION HEADER
        authorization_header = self.get_authorization_header(
            credential_scope=credential_scope, signature=signature
        )

        # ADD SIGV4 HEADERS TO THE ORIGINAL REQUEST
        headers = {
            "x-amz-date": timestamp,
            "authorization": authorization_header,
            "x-amz-content-sha256": payload_hash,
            "x-amz-request-sha256": canonical_request_hash,
        }
        if self._token:
            headers["x-amz-security-token"] = self._token
        request.headers.update(headers)

        return request
