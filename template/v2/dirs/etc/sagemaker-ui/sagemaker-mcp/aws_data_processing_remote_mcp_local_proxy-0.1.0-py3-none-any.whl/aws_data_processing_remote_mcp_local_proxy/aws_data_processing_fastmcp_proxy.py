import logging
import os
import tempfile
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path

import httpx
from fastmcp import FastMCP
from fastmcp.client.transports import StreamableHttpTransport

from aws_data_processing_remote_mcp_local_proxy.utils.sigv4_custom_auth import SigV4CustomAuth

# Configure logging
log_dir = Path(tempfile.gettempdir()) / "dataprocessing-mcp-server"
log_dir.mkdir(parents=True, exist_ok=True)
log_file = log_dir / "proxy_mcp_server.log"

# Create a rotating file handler that rotates daily and keeps 30 days of logs
file_handler = TimedRotatingFileHandler(
    filename=str(log_file),
    when="midnight",  # Rotate at midnight
    interval=1,  # Rotate every 1 day
    backupCount=30,  # Keep 30 days of logs
    encoding="utf-8",
)
file_handler.setLevel(logging.DEBUG)

# Configure the formatter
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
file_handler.setFormatter(formatter)

# Create console handler for debugging
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(formatter)

# Clear any existing handlers to avoid conflicts
logging.getLogger().handlers.clear()

# Configure basic logging
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[file_handler, console_handler],
    force=True,
)

logger = logging.getLogger("dp-local-proxy")
logger.setLevel(logging.DEBUG)

# Print the log file path to console so you know where to find it
print(f"Log file location: {log_file}")

# Test logging immediately
logger.info(
    f"Logging initialized - writing to: {log_file}, rotating at midnight and keep for 30 days"
)
logger.warning("Proxy starting up...")

# Force flush to ensure messages are written
file_handler.flush()

aws_region = os.getenv("AWS_REGION") or "us-east-1"  # Default region if not specified
stage = os.getenv("STAGE") or "prod"  # Default stage if not specified
selected_servers = os.getenv("SELECTED_SERVERS") or "*"


# Custom client factory to ensure each request is signed with SigV4
def create_sigv4_client(headers=None, auth=None, **kwargs):
    """
    Create an httpx.AsyncClient with SigV4 authentication.

    Args:
        headers: Headers to include in requests
        auth: Auth parameter (ignored as we provide our own)
        **kwargs: Additional arguments to pass to httpx.AsyncClient
    """
    # Create a copy of kwargs to avoid modifying the passed dict
    client_kwargs = {
        "follow_redirects": True,
        "timeout": httpx.Timeout(180.0, connect=180.0, read=180.0, write=180.0),
        "limits": httpx.Limits(max_keepalive_connections=1, max_connections=5),
        **kwargs,
    }

    # Add headers if provided, including required Accept header for FastMCP
    default_headers = {"Accept": "application/json, text/event-stream"}
    if headers is not None:
        default_headers.update(headers)
    client_kwargs["headers"] = default_headers

    logger.info(
        "Creating httpx.AsyncClient with custom headers: %s", client_kwargs.get("headers", {})
    )

    # Create the client with SigV4 auth
    logger.info("Creating httpx.AsyncClient with SigV4 authentication")

    service_name = "dataprocessing-mcp" if stage == "prod" else "dataprocessing-mcp-test"
    return httpx.AsyncClient(
        auth=SigV4CustomAuth(region=aws_region, service=service_name),
        **client_kwargs,
        event_hooks={"response": [handle_error_response]},
    )


# Custom hook to post process response with error.
# need this to expose the error details in error message.
async def handle_error_response(response):
    """Event hook to handle HTTP error responses and extract details"""
    if response.is_error:
        try:
            # Read response content to extract error details
            await response.aread()
        except Exception as e:
            logger.error(f"Failed to read response: {e}")

        # Try to extract error details with fallbacks
        error_msg = ""
        try:
            error_details = response.json()
            logger.error(f"HTTP {response.status_code} Error Details: {error_details}")
            error_msg = f"HTTP {response.status_code}: {error_details} for url {response.url}"
            response.raise_for_status()
        except httpx.HTTPStatusError as e:
            # replace the error message and throw HTTP error
            if error_msg:
                raise httpx.HTTPStatusError(
                    message=error_msg, request=e.request, response=e.response
                )
            raise e


def main():
    stage_name = "prod" if stage.lower() == "" else "-gamma"
    base_endpoint_url = f"https://dataprocessing-mcp{stage_name}.{aws_region}.api.aws/"
    spark_troubleshooting_url = base_endpoint_url + "spark-troubleshooting/mcp"
    spark_upgrade_url = base_endpoint_url + "spark-upgrade/mcp"
    spark_code_recommendation_url = base_endpoint_url + "spark-code-recommendation/mcp"

    def create_transport(url):
        return StreamableHttpTransport(
            url=url,
            httpx_client_factory=create_sigv4_client,
        )

    data_processing_server: FastMCP = FastMCP(name="dataprocessing-mcp")

    if selected_servers == "*" or "spark_troubleshooting" in selected_servers:
        spark_troubleshooting_server_proxy = FastMCP.as_proxy(
            create_transport(spark_troubleshooting_url), name="Spark Troubleshooting Server Proxy"
        )
        data_processing_server.mount(spark_troubleshooting_server_proxy)

    if selected_servers == "*" or "spark_upgrade" in selected_servers:
        spark_upgrade_server_proxy = FastMCP.as_proxy(
            create_transport(spark_upgrade_url), name="Spark Upgrade Server Proxy"
        )
        data_processing_server.mount(spark_upgrade_server_proxy)

    if selected_servers == "*" or "spark_code_recommendation" in selected_servers:
        spark_code_recommendation_server_proxy = FastMCP.as_proxy(
            create_transport(spark_code_recommendation_url),
            name="Spark Code Recommendation Server Proxy",
        )
        data_processing_server.mount(spark_code_recommendation_server_proxy)

    data_processing_server.run()


if __name__ == "__main__":
    main()
