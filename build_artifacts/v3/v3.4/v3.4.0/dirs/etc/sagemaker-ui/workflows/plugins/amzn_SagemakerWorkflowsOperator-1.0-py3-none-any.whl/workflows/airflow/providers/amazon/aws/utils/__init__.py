import os

workflows_env_key = "WORKFLOWS_ENV"


def is_local_runner():
    return os.getenv(workflows_env_key, "") == "Local"
