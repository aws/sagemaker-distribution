from airflow import AirflowException
from airflow.sensors.base import BaseSensorOperator
from airflow.utils.context import Context

from workflows.airflow.providers.amazon.aws.hooks.sagemaker_workflows import NotebookHook


class NotebookSensor(BaseSensorOperator):
    """
    Waits for an Sagemaker Workflows Notebook execution to reach any of the status below.

    'FAILED', 'STOPPED', 'COMPLETED'

    .. seealso::
        For more information on how to use this sensor, take a look at the guide:
        :ref:`howto/sensor:NotebookSensor`

    :param execution_id: The Sagemaker Workflows Notebook running execution identifier
    :param execution_name: The Sagemaker Workflows Notebook unique execution name
    """

    def __init__(self, *, execution_id: str, execution_name: str, **kwargs):
        super().__init__(**kwargs)
        self.execution_id = execution_id
        self.execution_name = execution_name
        self.success_state = ["COMPLETED"]
        self.in_progress_states = ["PENDING", "RUNNING"]

    def hook(self):
        return NotebookHook(execution_name=self.execution_name)

    # override from base sensor
    def poke(self):
        status = self.hook().get_execution_status(execution_id=self.execution_id)

        if status in self.success_state:
            self.log.info(f"Exiting Execution {self.execution_id} State: {status}")
            return True
        elif status in self.in_progress_states:
            return False
        else:
            error_message = f"Exiting Execution {self.execution_id} State: {status}"
            self.log.info(error_message)
            raise AirflowException(error_message)

    def execute(self, context: Context):
        # This will invoke poke method in the base sensor
        self.log.info(
            f"Polling Sagemaker Workflows Notebook execution: {self.execution_name} and execution id: {self.execution_id}"
        )
        super().execute(context=context)
