from airflow.triggers.base import BaseTrigger


class NotebookJobTrigger(BaseTrigger):
    """
    Watches for a notebook job, triggers when it finishes.

    Examples:
     .. code-block:: python

        from workflows.airflow.providers.amazon.aws.operators.sagemaker_workflows import NotebookOperator

        notebook_operator = NotebookJobTrigger(
            execution_id='notebook_job_1234'
            execution_name='notebook_task',
            poll_interval=10,
        )
    :param execution_id: A unique, meaningful id for the task.
    :param execution_name: A unique, meaningful name for the task.
    :param poll_interval: Interval in seconds to check the notebook execution status.
    """

    def __init__(self, execution_id, execution_name, poll_interval, **kwargs):
        super().__init__(**kwargs)
        self.execution_id = execution_id
        self.execution_name = execution_name
        self.poll_interval = poll_interval

    def serialize(self):
        return (
            # dynamically generate the fully qualified name of the class
            self.__class__.__module__ + "." + self.__class__.__qualname__,
            {
                "execution_id": self.execution_id,
                "execution_name": self.execution_name,
                "poll_interval": self.poll_interval,
            },
        )

    async def run(self):
        pass
