from airflow.plugins_manager import AirflowPlugin

from workflows.airflow.providers.amazon.aws.hooks.sagemaker_workflows import NotebookHook
from workflows.airflow.providers.amazon.aws.operators.sagemaker_workflows import NotebookOperator


class WorkflowsPlugin(AirflowPlugin):
    name = "sagemaker_workflows_airflow_plugin"

    hooks = [NotebookHook]
    operators = [NotebookOperator]
